using ShopApp.ViewModels;

namespace ShopApp.Views;

public partial class RegistroUsuariosPage : ContentPage
{
	public RegistroUsuariosPage(RegistroUsuariosViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}
}