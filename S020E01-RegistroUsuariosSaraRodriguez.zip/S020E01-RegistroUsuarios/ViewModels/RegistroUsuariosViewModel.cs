﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using ShopApp.Services;
using ShopApp.Views;

namespace ShopApp.ViewModels;

public partial class RegistroUsuariosViewModel : ViewModelGlobal
{
    [ObservableProperty]
    string nombre;

    [ObservableProperty]
    string apellido;

    [ObservableProperty]
    string email;

    [ObservableProperty]
    string userName;

    [ObservableProperty]
    string telefono;

    [ObservableProperty]
    string password; 

    private readonly INavegacionService _navegacionService;

    private readonly SecurityService _securityService;

    public RegistroUsuariosViewModel(INavegacionService navegacionService, SecurityService securityService)
    {
        _navegacionService = navegacionService;
        _securityService = securityService; 
    }
       

    [RelayCommand]
    private async Task RegistrarUsuario()
    {
        var resultado = await _securityService.RegisterUser(Nombre, Apellido, Email, UserName, Telefono,Password);
        if (resultado)
        {
            Application.Current.MainPage = new AppShell();
        }
        else
        {
            await Shell.Current.DisplayAlert("Mensaje", "Registro de usuario erroneo", "Aceptar");
        }
    }   

    [RelayCommand]
    async Task TapIniciarSesion()
    {
        var uri = $"{nameof(LoginPage)}";
        await _navegacionService.GoToAsync(uri);
    }
}
