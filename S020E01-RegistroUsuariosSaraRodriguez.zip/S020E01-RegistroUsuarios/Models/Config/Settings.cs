﻿namespace ShopApp.Models.Config;

public class Settings
{
    public string UrlBase { get; set; }

}

