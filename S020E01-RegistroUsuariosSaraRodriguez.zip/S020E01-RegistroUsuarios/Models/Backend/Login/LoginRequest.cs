﻿namespace ShopApp.Models.Backend.Login;

public class LoginRequest
{
    public string Email { get; set; }

    public string Password { get; set; }
}

