﻿namespace ShopApp.Models.Backend.Inmueble;

public class BookmarkRequest
{
    public string UsuarioId { get; set; }
    public int InmuebleId { get; set; }
}

